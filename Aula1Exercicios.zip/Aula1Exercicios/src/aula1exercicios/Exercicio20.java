package aula1exercicios;

import java.util.Scanner;

public class Exercicio20 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o tipo de combustível (Álcool ou Gasolina): ");
        String combustivel = leia.nextLine().toLowerCase();
      
        System.out.print("Digite a quantidade de litros: ");
        double litros = leia.nextDouble();
      
        double precoPorLitro = 0.0;
        double desconto = 0.0;
      
        if (combustivel.equals("alcool")) {
            precoPorLitro = 3.5;
            desconto = litros <= 20.0 ? 0.03 : 0.05;
        } else {
            if (!combustivel.equals("gasolina")) {
                System.out.println("Tipo de combustível inválido!");
                leia.close();
            return;
            }

            precoPorLitro = 4.5;
            desconto = litros <= 20.0 ? 0.04 : 0.06;
        }

        double valorSemDesconto = litros * precoPorLitro;
        double valorDesconto = valorSemDesconto * desconto;
        double valorFinal = valorSemDesconto - valorDesconto;
      
        System.out.printf("Valor total a pagar: R$ %.2f\n", valorFinal);
      
        leia.close();
   }
}

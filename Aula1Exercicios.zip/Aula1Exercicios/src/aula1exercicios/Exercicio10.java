package aula1exercicios;

import java.util.Scanner;

public class Exercicio10 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o consumo do carro (em km/l): ");
        double consumo = leia.nextDouble();
      
        System.out.print("Digite a distância a ser percorrida (em km): ");
        double distancia = leia.nextDouble();
      
        System.out.print("Digite o preço do litro de combustível (em R$): ");
        double precoCombustivel = leia.nextDouble();
      
        double custo = distancia / consumo * precoCombustivel;
      
        System.out.printf("O custo estimado com combustível é: R$ %.2f%n", custo);
        
        leia.close();
   }
}

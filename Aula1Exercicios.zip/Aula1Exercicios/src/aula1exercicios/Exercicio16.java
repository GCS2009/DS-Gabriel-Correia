package aula1exercicios;

import java.util.Scanner;

public class Exercicio16 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o salário mensal atual do funcionário: ");
        double salarioAtual = leia.nextDouble();
      
        System.out.print("Digite o percentual de reajuste (%): ");
        double percentualReajuste = leia.nextDouble();
      
        double novoSalario = salarioAtual + salarioAtual * percentualReajuste / 100.0;
      
        System.out.printf("O novo salário após o reajuste é: R$ %.2f%n", novoSalario);
      
        leia.close();
   }
}

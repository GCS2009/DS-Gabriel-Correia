package aula1exercicios;

import java.util.Scanner;

public class Exercicio14 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o número total de eleitores: ");
        int totalEleitores = leia.nextInt();
      
        System.out.print("Digite o número de votos brancos: ");
        int votosBrancos = leia.nextInt();
      
        System.out.print("Digite o número de votos nulos: ");
        int votosNulos = leia.nextInt();
      
        System.out.print("Digite o número de votos válidos: ");
        int votosValidos = leia.nextInt();
      
        double percentualBrancos = (double)votosBrancos / (double)totalEleitores * 100.0;
        double percentualNulos = (double)votosNulos / (double)totalEleitores * 100.0;
        double percentualValidos = (double)votosValidos / (double)totalEleitores * 100.0;
      
        System.out.printf("Percentual de votos brancos: %.2f%%\n", percentualBrancos);
        System.out.printf("Percentual de votos nulos: %.2f%%\n", percentualNulos);
        System.out.printf("Percentual de votos válidos: %.2f%%\n", percentualValidos);
      
        leia.close();
   }
}

package aula1exercicios;

import java.util.Scanner;

public class Exercicio4 {
     public static void main(String[] args) {
         Scanner leia = new Scanner(System.in);
         
         Double largura, comprimento, area;
         
         System.out.println("Digite a largura do retangulo:");
         largura = leia.nextDouble();
         
         System.out.println("Digite o comprimento do retangulo:");
         comprimento = leia.nextDouble();
         
         area = comprimento * largura;
         
         System.out.println("A área do retangulo é: "+area);                  
    }
}
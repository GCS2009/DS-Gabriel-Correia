package aula1exercicios;

import java.util.Scanner;

public class Exercicio11 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite um valor: ");
        int valor = leia.nextInt();
      
        int antecessor = valor - 1;
      
        System.out.println("O antecessor de " + valor + " é: " + antecessor);
      
        leia.close();
   }
}
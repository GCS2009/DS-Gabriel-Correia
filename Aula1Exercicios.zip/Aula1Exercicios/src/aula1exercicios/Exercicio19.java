package aula1exercicios;

import java.util.Scanner;

public class Exercicio19 {
   public static void main(String[] args) {
      Scanner leia = new Scanner(System.in);
      
      System.out.print("Digite o nome: ");
      String nome = leia.nextLine();
      
      System.out.print("Digite a altura (em metros): ");
      double altura = leia.nextDouble();
      
      System.out.print("Digite o sexo (M para masculino, F para feminino): ");
      char sexo = leia.next().charAt(0);
      
      double pesoIdeal;
      
      if (sexo != 'M' && sexo != 'm') {
         if (sexo != 'F' && sexo != 'f') {
            
             System.out.println("Sexo inválido! Por favor, insira 'M' para masculino ou 'F' para feminino.");
            
             leia.close();
            
             return;
         }

         pesoIdeal = 62.1 * altura - 44.7;
      } else {
         
         pesoIdeal = 72.7 * altura - 58.0;
      }

      System.out.printf("%s, seu peso ideal é: %.2f kg\n", nome, pesoIdeal);
      
      leia.close();
   }
}
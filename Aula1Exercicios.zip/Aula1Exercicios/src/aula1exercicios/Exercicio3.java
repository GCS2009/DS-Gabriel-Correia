package aula1exercicios;

import java.util.Scanner;

public class Exercicio3 {
     public static void main(String[] args) {
         Scanner leia = new Scanner(System.in);
         
         String nome;
         double salario, vendas, total;
         
         System.out.println("Qual é seu nome?");
         nome = leia.nextLine();
         
         System.out.println("Qual é seu salario fixo?");
         salario = leia.nextDouble();
         
         System.out.println("Qual é o valor de vendas?");
         vendas = leia.nextDouble();
         
         total = salario + (vendas*15/100);
         
         System.out.println("O salario total é "+total);
     
     }
}

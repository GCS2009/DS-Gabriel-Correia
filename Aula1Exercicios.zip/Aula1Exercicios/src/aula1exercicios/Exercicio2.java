package aula1exercicios;

public class Exercicio2 {
    public static void main(String[] args) {    

    int numero1 = 10;
    int numero2 = 10;
    int resultadoS;
    int resultadoA;
    int resultadoM;
    int resultadoD;
        
        resultadoA = numero1 + numero2;
        resultadoS = numero1 - numero2;
        resultadoM = numero1 * numero2;
        resultadoD = numero1 / numero2;
        
        System.out.println("A soma dos valores é:"+resultadoA);
        System.out.println("A subtração dos valores é:"+resultadoS);
        System.out.println("A multiplicação dos valores é:"+resultadoM);
        System.out.println("A divisão dos valores é:"+resultadoD);
     
    }
}


package aula1exercicios;

import java.util.Scanner;

public class Exercicio13 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite a idade em anos: ");
        int anos = leia.nextInt();
      
        System.out.print("Digite a idade em meses: ");
        int meses = leia.nextInt();
      
        System.out.print("Digite a idade em dias: ");
        int dias = leia.nextInt();
      
        int idadeEmDias = anos * 365 + meses * 30 + dias;
      
        System.out.println("A idade total em dias é: " + idadeEmDias + " dias.");
      
        leia.close();
   }
}

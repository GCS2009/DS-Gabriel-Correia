package aula1exercicios;


import java.util.Scanner;

public class Exercicio7 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        
        System.out.print("Digite a distância da viagem (em km): ");
        double distancia = leia.nextDouble();
        
        System.out.print("Digite o consumo do carro com gasolina (em km/l): ");
        double consumoGasolina = leia.nextDouble();
        
        System.out.print("Digite o consumo do carro com álcool (em km/l): ");
        double consumoAlcool = leia.nextDouble();
        
        System.out.print("Digite o preço da gasolina (em R$/litro): ");
        double precoGasolina = leia.nextDouble();
        
        System.out.print("Digite o preço do álcool (em R$/litro): ");
        double precoAlcool = leia.nextDouble();
        
        System.out.print("Digite o tipo de combustível (1 para gasolina, 2 para álcool): ");
        int tipoCombustivel = leia.nextInt();
      
        double custoTotal = 0.0;
        if (tipoCombustivel == 1) {
        
            custoTotal = distancia / consumoGasolina * precoGasolina;
        
        System.out.printf("O custo estimado com gasolina é: R$ %.2f%n", custoTotal);
        } else if (tipoCombustivel == 2) {
         
            custoTotal = distancia / consumoAlcool * precoAlcool;
         
        System.out.printf("O custo estimado com álcool é: R$ %.2f%n", custoTotal);
        } else {
        
        System.out.println("Tipo de combustível inválido!");
        
        }

      leia.close();
   }
}

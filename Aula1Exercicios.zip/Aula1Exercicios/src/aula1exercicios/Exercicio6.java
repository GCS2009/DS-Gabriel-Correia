package aula1exercicios;

import java.util.Scanner;

public class Exercicio6 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        
        System.out.print("Digite a distância da viagem (em km): ");
        int distancia = leia.nextInt();
        
        System.out.print("Digite o consumo médio do carro (em km/l): ");
        int consumoMedio = leia.nextInt();
        
        System.out.print("Digite o preço do combustível (em R$/litro): ");
        int precoCombustivel = leia.nextInt();
        
        int custoTotal = distancia / consumoMedio * precoCombustivel;
        
        System.out.println("O custo estimado com combustível é: R$ " + custoTotal);
        
        leia.close();
   }
}

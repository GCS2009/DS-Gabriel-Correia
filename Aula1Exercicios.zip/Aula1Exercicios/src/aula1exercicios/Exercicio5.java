package aula1exercicios;

public class Exercicio5 {
    public static void main(String[] args) {
    
      int a = 5;
      int b = 10;
      
      System.out.println("Valores antes da troca:");
      System.out.println("a = " + a);
      System.out.println("b = " + b);
      System.out.println("\nValores depois da troca:");
      System.out.println("a = " + b);
      System.out.println("b = " + a);
   }
}

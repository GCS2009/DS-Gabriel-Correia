package aula1exercicios;

import java.util.Scanner;

public class Exercicio17 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o custo de fábrica do carro: ");
        double custoFabrica = leia.nextDouble();
      
        double custoDistribuidor = custoFabrica * 28.0 / 100.0;
        double custoImpostos = custoFabrica * 45.0 / 100.0;
        double custoFinal = custoFabrica + custoDistribuidor + custoImpostos;
      
        System.out.printf("O custo final ao consumidor é: R$ %.2f%n", custoFinal);
      
        leia.close();
   }
}

package aula1exercicios;

import java.util.Scanner;

public class Exercicio18 {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
      
        System.out.print("Digite o número de carros vendidos: ");
        int numCarrosVendidos = leia.nextInt();
      
        System.out.print("Digite o valor total das vendas: R$ ");
        double valorTotalVendas = leia.nextDouble();
      
        System.out.print("Digite o salário fixo do vendedor: R$ ");
        double salarioFixo = leia.nextDouble();
      
        System.out.print("Digite o valor da comissão por carro vendido: R$ ");
        double comissaoPorCarro = leia.nextDouble();
      
        double comissaoTotal = (double)numCarrosVendidos * comissaoPorCarro;
        double comissaoPorVendas = 0.05 * valorTotalVendas;
        double salarioFinal = salarioFixo + comissaoTotal + comissaoPorVendas;
      
        System.out.printf("O salário final do vendedor é: R$ \n"+ salarioFinal);
     
      
        leia.close();
   
    }
}
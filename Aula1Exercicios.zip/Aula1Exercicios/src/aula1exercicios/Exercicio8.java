package aula1exercicios;

import java.util.Scanner;

public class Exercicio8 {
   public Exercicio8() {
   }

   public static void main(String[] args) {
      Scanner leia = new Scanner(System.in);
      
      System.out.print("Digite a distância da viagem (em km): ");
      double distancia = leia.nextDouble();
      
      System.out.print("Digite o consumo do carro (em km/l): ");
      double consumo = leia.nextDouble();
      
      System.out.print("Digite o preço do combustível (em R$/litro): ");
      double precoCombustivel = leia.nextDouble();
     
      double litrosNecessarios = distancia / consumo;
      double custoTotal = litrosNecessarios * precoCombustivel;
      
      System.out.printf("Serão necessários %.2f litros de combustível.%n", litrosNecessarios);
      
      System.out.printf("O custo estimado com combustível é: R$ %.2f%n", custoTotal);
      
      leia.close();
   }
}
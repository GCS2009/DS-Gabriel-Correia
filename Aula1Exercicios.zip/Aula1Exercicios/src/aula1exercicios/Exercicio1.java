package aula1exercicios;

public class Exercicio1 {
    public static void main(String[] args) {
    
    System.out.println("Soma dos valores");
    
    int numero1 = 15;
    int numero2 = 15;
    int resultado;
        
        resultado = numero1 + numero2;
        
        System.out.println("A soma dos valores é:"+resultado);

    }
}
